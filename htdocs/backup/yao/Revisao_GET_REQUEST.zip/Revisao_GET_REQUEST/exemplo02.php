<?php
	echo "<h3> Recuperando os dados </h3>";
	echo "Nome: ".$_REQUEST['nome'];
	echo "<br>";
	echo "E-mail: ".$_REQUEST['email'];
?>




