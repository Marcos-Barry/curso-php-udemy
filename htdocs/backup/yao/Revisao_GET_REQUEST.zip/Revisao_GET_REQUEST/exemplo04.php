<?php
	echo "<h3> Recuperando os dados </h3>";
	echo "Id: ".$_GET['id']; 
?>




