<html>
<head>
	<title> Minha página web - Formulário - Recuperando os Dados</title>
</head>
<body>
	<?php
		$idBanco = 10;
		$nomeUser = "admin"
	?>
	<a href="exemplo07_dados.php?id=<?php echo $idBanco;?>&user=<?php echo $nomeUser;?> "> Passando dados via URL </a>

</body>
</html>






