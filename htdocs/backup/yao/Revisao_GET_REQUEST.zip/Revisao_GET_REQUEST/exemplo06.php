<?php
	echo "<h3> Recuperando os dados </h3>";
	echo "Id: ".$_REQUEST['id']; 
	echo "<br>";
	echo "User: ".$_REQUEST['user']; 
?>




