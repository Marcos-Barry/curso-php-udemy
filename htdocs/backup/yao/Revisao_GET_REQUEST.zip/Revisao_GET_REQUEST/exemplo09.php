<html>
<head>
	<title> Minha página web - Formulário - Recuperando os Dados</title>
</head>
<body>
	<?php
		$idBanco = 10;
		$nomeUser = "admin";
		echo "<a href='exemplo09_dados.php?id=".$idBanco."&user=".$nomeUser."'>Passando dados via URL </a>";
	?>
</body>
</html>






